# DSH Show Git Brunch

在 DSH 對話頁頭部「模式」右側顯示目前對話工作區的 Git 分支。目錄名稱保留 show_git_brunch；安裝包名稱為 dsh-show-git-brunch。

## 行為

- 顯示分支圖示與分支名；長名稱截斷，滑鼠停留可查看完整名稱。
- 非 Git 工作區、沒有 Git、目錄不存在或查詢失敗時完全隱藏。
- 支援尚無提交的新倉庫、Git worktree、倉庫子目錄；detached HEAD 顯示 detached 加短 commit ID。
- 頁面可見時每 5 秒更新；切換對話、頁面取得焦點及重新可見時更新。
- 僅執行唯讀 Git 命令，不切換分支、不修改 Git 設定、索引或工作區。

## 相容性

需要 Node.js >=22.19 與主機 PATH 上的 Git。適用於具備 Connection 自訂 RPC、workspaceRegistry 與 conversation.session.header.actions 插槽的 DSH Web 版本。開發依據為本機 DSH 0.1.1-rc.2 checkout 的介面；DSH 尚在預發布階段，不保證其他版本介面一致。

查詢目標由後端 workspaceRegistry 中經對話 header 驗證的 sessionIds 決定。瀏覽器只傳 sessionId，不可傳任意路徑；未歸屬已登記工作區的對話不顯示。Git 在 DSH 主機本機執行，未提供遠端容器／E2B Git 適配。專用 RPC 沿用 DSH trusted-host 來源檢查，這不是額外的登入認證層。

## 開發與打包（PowerShell）

在本目錄執行：

    npm.cmd run build
    npm.cmd test
    npm.cmd run check
    npm.cmd pack

本插件沒有運行時或開發套件依賴；前端使用 DSH 的共享 React，不附帶第二份 React。測試以 Node.js 內建 node:test 與輕量測試替身驗證插件邊界。

build 產生 lib/client.js 的 DSH closure-factory 產物。修改 src/client.mjs 或 src/polling.mjs 後必須重新 build；不要直接修改產物。check 檢查語法與產物是否與來源一致。

## 安裝與啟用

從此插件目錄執行 DSH 原生安裝命令（不需要修改 DSH 原始碼）：

    dsh plugin --profile web add 'link:.'

正式安裝可以使用 npm pack 產生的壓縮檔絕對路徑：

    dsh plugin --profile web add 'file:C:\path\to\dsh-show-git-brunch-0.1.0.tgz'

安裝完成後，重新啟動原本的 DSH Web 主機，然後刷新原本頁面（例如 http://127.0.0.1:3080）。安裝只影響指定的 web profile，若實際使用其他 profile，請換成其名稱。不要另起替代 Web/Vite 服務來更新既有頁面。

package.json 的 bundle patch 會將插件掛載到 host plane；前端會由 DSH 模組系統探索載入。單純 npm/pnpm add 不等於啟用 DSH bundle。新安裝或修改 manifest 後需要重啟主機；此專案不承諾 HMR，開發修改請 build 後刷新，必要時重啟。

移除：

    dsh plugin --profile web remove dsh-show-git-brunch

移除後重新啟動原本主機並刷新頁面。

## 人工驗收

1. 打開屬於 Git 工作區的對話，確認模式右側出現分支名。
2. 在外部終端切換分支，確認 5 秒內更新；回到頁面時立即更新。
3. 切換至非 Git 工作區的對話，確認沒有標籤或佔位文字，亦不短暫顯示上一個分支。
4. 測試 detached HEAD、新建空倉庫與 worktree。
5. 隱藏頁面時不再發出週期請求；卸載插件後沒有殘留。

本專案的自動化測試與產物檢查不等同於已安裝到你目前使用中的 GUI；實際安裝及瀏覽器驗證狀態以交付說明為準。
